package com.suaempresa.controleponto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControlePontoApplication {
    public static void main(String[] args) {
        SpringApplication.run(ControlePontoApplication.class, args);
    }
}
